# Import statements
import sys
import numpy as np
import math
import string
import random as ole
import matplotlib.pyplot as plt
import numpy as np

# Opening file to read_data
def load_data(filename):
	data = []
	labels = []
	i = 0
	f = open(filename,'r')
	for line in f:
		values = line.split(' ')
		values = map(int, values)
		if(filename != proj_filename):
			label = int(values.pop())
			labels.append(label)
		data.append(values)
		i = i+1
	return data, labels

# data = arb_x
# k = k
# iter = iter
'''
def find_centers(k, train_data, train_labels, valid_data, valid_labels):
	# Takes random sample from data
	size = len(train_data)
	rand = ole.randint(0,size)
	
	# TODO: replace arb_x and arb_label with classifier
	arb_x = train_data[0]
	arb_label = train_labels[0]
	
	neighbours = np.asarray([0.0 for x in range(size)])
	# Iterates through the dataset
	for i in range(size):
		neighbours[i] = euclid_distance(arb_x, train_data[i])		
	# The argsort sorts the euclidian distances and gives the indexes of smallest distances
	nearest = neighbours.argsort()
	# This gives the k-closest neighbours' indexes
	nearest = nearest[-1:-k]
	print nearest
	# Looping through the nearest neighbours to test accuracy
	for k_d in range(k):
		index = nearest[k_d]
		target = valid_labels[index]
		if (arb_label == target):
			print "yes"
	
'''
# Function: K Means
# -------------
# K-Means is an algorithm that takes in a dataset and a constant
# k and returns k classifier (which define clusters of data in the
# dataset which are similar to one another).
def k_means(data, labels, k, max_iter):
	# Initialize classifier randomly
	num_labels = 10
	index = len(data)
	# TODO:: Initialize data_set to dict with key = label[i] and item = data[i]
	data_set = {index: (labels, data)}

	classifier = initialize_classifier(dataSet, num_labels, k)

	# Initialize vars
	counter = 0
	old_classifier = None

	# Run the main k-means algorithm
	while cluster_condition(old_classifier, classifier, counter, max_iter):
	    # Save old classifier for k-means condition. Iterating
	    old_classifier = classifier
	    counter += 1
	    
	    # Assign labels to each datapoint based on classifier
	    labels = getLabels(dataSet, classifier)
	    
	    # Assign classifier based on datapoint labels
	    classifier = getClassifier(dataSet, labels, k)
	    
	    # TODO: Print out accuracy

	# We can get the labels too by calling getLabels(dataSet, classifier)
	return classifier


# Function: cluster_condition
# -------------
# Returns True if k-means is not done. K-means terminates either
# because it has run a maximum number of iterations OR the classifier
# stop changing.
def cluster_condition(old_classifier, classifier, counter):
    if counter <= max_iter: return False
    return old_classifier != classifier

# Function: Get Labels
# -------------
# Returns a label for each piece of data in the dataset. 
def getLabels(dataSet, classifier):
    
    # For each element in the dataset, chose the closest centroid.
    min(euclid_distance(center, element))	 
    # Make that centroid the element's label.

# Function: Get classifier
# -------------
# Returns k random classifier, each of dimension n.
#def getclassifier(dataSet, labels, k):
    # Each centroid is the geometric mean of the points that
    # have that centroid's label. Important: If a centroid is empty (no points have
    # that centroid's label) you should randomly re-initialize it.


def initialize_classifier(data_set, numFeatures, k):
	# Creating a dictionary to store the clusters
	clusters = {}
	# Creating a hashed dataset to get the values 
	for label in numFeatures:
		ole.choice(data_set.keys())

	# Initializing clusters so we get data organized
	

	# Populating the clusters with random data points and labels
	
		for i in range(1, k):
			clusters.setdefault(num, []).append()


def next_random(data, label):
	dist = {}




# Finds the euclid distance for all the 784 dimensions of the data
def euclid_distance(target,data):
	distance = 0
	x_train = np.asarray(data)
	center = np.asarray(target)
	distance = np.sqrt(np.sum((x_train - center) ** 2))
	return distance



def vectorize(value):
	array = np.asarray([0 for i in range(10)])
	array[value] = 1
	return array

def plot_data(data, label):
	x = data
	y = label
	plt.plot(x,y)
	

# Filenames for importing
train_filename = "/Users/raghav/Documents/workspace/cse151/hw2/data/hw2train.txt"
test_filename = "/Users/raghav/Documents/workspace/cse151/hw2/data/hw2test.txt"
valid_filename = "/Users/raghav/Documents/workspace/cse151/hw2/data/hw2validate.txt"
proj_filename = "/Users/raghav/Documents/workspace/cse151/hw2/data/projection.txt"

# Getting the data as np arrays
train_data, train_labels = np.asarray(load_data(train_filename))
valid_data, valid_labels = np.asarray(load_data(valid_filename))
test_data, test_labels = np.asarray(load_data(test_filename))
#proj_matrix = np.asarray(load_data(proj_filename))

#initialize_classifier(train_data, train_labels, 10,1)

# Running k-means clustering on the data
#find_centers(3, train_data, train_labels, valid_data, valid_labels)
k_means(train_data, train_labels, 3, 20)
#plot_data(train_data)









